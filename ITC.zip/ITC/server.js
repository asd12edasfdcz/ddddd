let startValue = "";
let endValue = "";

const startPicker = flatpickr("#startInput", {
  enableTime: true,
  dateFormat: "Y-m-d H:i",
  locale: "ko",
  clickOpens: false,
  onChange: (selectedDates, dateStr) => {
    startValue = dateStr;
    document.getElementById("startSelected").innerText = "선택된 시작: " + dateStr;
  },
  onReady: (selectedDates, dateStr, instance) => {
    const footer = document.createElement("div");
    footer.style.textAlign = "center";
    footer.style.marginTop = "8px";

    const setBtn = document.createElement("button");
    setBtn.textContent = "설정";
    setBtn.onclick = () => instance.close();

    const cancelBtn = document.createElement("button");
    cancelBtn.textContent = "취소";
    cancelBtn.style.marginLeft = "8px";
    cancelBtn.onclick = () => {
      startValue = "";
      document.getElementById("startSelected").innerText = "";
      instance.clear();
      instance.close();
    };

    footer.appendChild(setBtn);
    footer.appendChild(cancelBtn);
    instance.calendarContainer.appendChild(footer);
  }
});

const endPicker = flatpickr("#endInput", {
  enableTime: true,
  dateFormat: "Y-m-d H:i",
  locale: "ko",
  clickOpens: false,
  onChange: (selectedDates, dateStr) => {
    endValue = dateStr;
    document.getElementById("endSelected").innerText = "선택된 종료: " + dateStr;
  },
  onReady: (selectedDates, dateStr, instance) => {
    const footer = document.createElement("div");
    footer.style.textAlign = "center";
    footer.style.marginTop = "8px";

    const setBtn = document.createElement("button");
    setBtn.textContent = "설정";
    setBtn.onclick = () => instance.close();

    const cancelBtn = document.createElement("button");
    cancelBtn.textContent = "취소";
    cancelBtn.style.marginLeft = "8px";
    cancelBtn.onclick = () => {
      endValue = "";
      document.getElementById("endSelected").innerText = "";
      instance.clear();
      instance.close();
    };

    footer.appendChild(setBtn);
    footer.appendChild(cancelBtn);
    instance.calendarContainer.appendChild(footer);
  }
});

// 버튼으로 달력 열기
document.getElementById("openStart").addEventListener("click", () => startPicker.open());
document.getElementById("openEnd").addEventListener("click", () => endPicker.open());
